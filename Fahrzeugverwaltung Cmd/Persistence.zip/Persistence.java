import com.fasterxml.jackson.databind.ObjectMapper;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

class Persistence {
    private String filenameOne = "Serialization\\players.json";
    private String filenameTwo = "Serialization\\team.json";
    private String filenameThree = "Serialization\\manager.json";
    private String filenameFour = "Serialization\\bench.json";
    private String filenameFive = "Serialization\\shop.json";
    private String filenameSix = "Serialization\\matches.json";
    private ObjectMapper mapper;

    public Persistence() {
        mapper = new ObjectMapper();
    }

    public List<Player> loadPlayers() {
        List<Player> players = new ArrayList<>();
        try {
            File jsonFile = new File(filenameOne);
            if (jsonFile.exists()) {
                Player[] playeRay = mapper.readValue(jsonFile, Player[].class);

                for (Player pers : playeRay) {
                    players.add(pers);
                }
            }
        } catch (IOException exception) {
            exception.printStackTrace();
        }
        return players;
    }

    public void savePlayers(List<Player> players) {
        try {
            File jsonFile = new File(filenameOne);
            mapper.writerWithDefaultPrettyPrinter().writeValue(jsonFile, players);
        } catch (IOException exception) {
            exception.printStackTrace();
        }
    }

    //

    public Team loadTeam() {
        Team team = new Team();
        try {
            File jsonFile = new File(filenameTwo);
            if (jsonFile.exists()) {
                team = mapper.readValue(jsonFile, Team.class);

            }
        } catch (IOException exception) {
            exception.printStackTrace();
        }
        return team;
    }

    public void saveTeam(Team team) {
        try {
            File jsonFile = new File(filenameTwo);
            mapper.writerWithDefaultPrettyPrinter().writeValue(jsonFile, team);
        } catch (IOException exception) {
            exception.printStackTrace();
        }
    }

    public Manager loadManager() {
        Manager manager = new Manager();
        try {
            File jsonFile = new File(filenameThree);
            if (jsonFile.exists()) {
                manager = mapper.readValue(jsonFile, Manager.class);

            }
        } catch (IOException exception) {
            exception.printStackTrace();
        }
        return manager;
    }

    public void saveManager(Manager manager) {
        try {
            File jsonFile = new File(filenameThree);
            mapper.writerWithDefaultPrettyPrinter().writeValue(jsonFile, manager);
        } catch (IOException exception) {
            exception.printStackTrace();
        }
    }

    public List<Player> loadBench() {
        List<Player> players = new ArrayList<>();
        try {
            File jsonFile = new File(filenameFour);
            if (jsonFile.exists()) {
                Player[] playeRay = mapper.readValue(jsonFile, Player[].class);

                for (Player pers : playeRay) {
                    players.add(pers);
                }
            }
        } catch (IOException exception) {
            exception.printStackTrace();
        }
        return players;
    }

    public void saveBench(List<Player> players) {
        try {
            File jsonFile = new File(filenameFour);
            mapper.writerWithDefaultPrettyPrinter().writeValue(jsonFile, players);
        } catch (IOException exception) {
            exception.printStackTrace();
        }
    }

    public List<Player> loadShop() {
        List<Player> players = new ArrayList<>();
        try {
            File jsonFile = new File(filenameFive);
            if (jsonFile.exists()) {
                Player[] playeRay = mapper.readValue(jsonFile, Player[].class);

                for (Player pers : playeRay) {
                    players.add(pers);
                }
            }
        } catch (IOException exception) {
            exception.printStackTrace();
        }
        return players;
    }

    public void saveShop(List<Player> players) {
        try {
            File jsonFile = new File(filenameFive);
            mapper.writerWithDefaultPrettyPrinter().writeValue(jsonFile, players);
        } catch (IOException exception) {
            exception.printStackTrace();
        }
    }

    public List<String> loadMatches() {
        List<String> players = new ArrayList<>();
        try {
            File jsonFile = new File(filenameSix);
            if (jsonFile.exists()) {
                String[] playeRay = mapper.readValue(jsonFile, String[].class);

                for (String pers : playeRay) {
                    players.add(pers);
                }
            }
        } catch (IOException exception) {
            exception.printStackTrace();
        }
        return players;
    }

    public void saveMatches(List<String> string) {
        try {
            File jsonFile = new File(filenameSix);
            mapper.writerWithDefaultPrettyPrinter().writeValue(jsonFile, string);
        } catch (IOException exception) {
            exception.printStackTrace();
        }
    }
}
